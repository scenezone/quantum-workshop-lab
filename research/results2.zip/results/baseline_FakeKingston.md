# Baseline v2: FakeKingston (no error mitigation)

Qiskit Aer with the `FakeKingston` noise model · 4000 shots per run · 20 transpiler seeds (1-20), best kept · 10 simulator repeats per configuration (seed 1234+i) · values are mean ± std over repeats.

Best-of-seeds rule: fewest two-qubit gates, then lowest depth. Selection uses compile metrics only, never the measured error.

## Counts circuits (optimization level 2)

| Circuit | Qubits | Logical CX | 2q gates (best) | 2q over seeds | Depth | TVD | Hellinger F | Shot-noise TVD |
|---|---|---|---|---|---|---|---|---|
| Bell | 2 | 1 | 1 | 1-1 | 7 | 0.015 ± 0.004 | 0.988 ± 0.002 | 0.006 |
| GHZ-3 | 3 | 2 | 2 | 2-2 | 10 | 0.027 ± 0.002 | 0.974 ± 0.002 | 0.006 |
| GHZ-5 | 5 | 4 | 4 | 4-4 | 16 | 0.037 ± 0.004 | 0.963 ± 0.004 | 0.006 |
| Grover-2 | 2 | 2 | 2 | 2-2 | 10 | 0.015 ± 0.001 | 0.985 ± 0.001 | 0.000 |
| Grover-3 | 3 | 24 | 37 | 37-39 | 133 | 0.092 ± 0.004 | 0.974 ± 0.002 | 0.006 |
| QFT-3 | 3 | 9 | 9 | 9-9 | 32 | 0.037 ± 0.003 | 0.963 ± 0.003 | 0.000 |
| QFT-4 | 4 | 18 | 17 | 17-19 | 55 | 0.065 ± 0.004 | 0.934 ± 0.004 | 0.000 |
| BV-4 | 5 | 3 | 3 | 3-3 | 9 | 0.029 ± 0.002 | 0.971 ± 0.002 | 0.000 |

## QAOA (optimization level 2)

| Circuit | Qubits | 2q gates (best) | 2q over seeds | Depth | Approx. ratio (noisy) | Approx. ratio (ideal) | Problem |
|---|---|---|---|---|---|---|---|
| QAOA-3 | 3 | 7 | 7-9 | 32 | 0.986 ± 0.002 | 0.994 | MaxCut triangle, max cut 2, gamma=2.880 beta=0.327 |
| QAOA-4 | 4 | 11 | 11-12 | 45 | 0.738 ± 0.004 | 0.750 | MaxCut 4-ring, max cut 4, gamma=2.749 beta=0.393 |

## Effect of optimization level

Counts circuits only for gates, depth and TVD (QAOA is scored separately). "Median-seed" is what a single random seed typically gives; "best" is best of all seeds.

| Opt level | Total 2q (best) | Total 2q (median seed) | Total depth | Mean TVD | Median TVD | Mean QAOA ratio |
|---|---|---|---|---|---|---|
| 0 | 126 | 129.0 | 612 | 0.201 | 0.202 | 0.816 |
| 1 | 96 | 96.0 | 360 | 0.125 | 0.140 | 0.861 |
| 2 | 75 | 78.0 | 272 | 0.040 | 0.033 | 0.862 |
| 3 | 70 | 75.0 | 254 | 0.035 | 0.026 | 0.863 |

## Per-circuit change

Primary metric is TVD (lower is better) or, for QAOA, approximation ratio (higher is better). Percentages are relative changes.

| Circuit | Metric | 2q gates L0 → L2 | Depth L0 → L2 | Metric L0 → L1 → L2 → L3 | Metric change L0 → L2 | 2q L2 / L3 | Metric L2 − L3 |
|---|---|---|---|---|---|---|---|
| Bell | TVD | 1 → 1 (+0%) | 8 → 7 (-12%) | 0.172 → 0.172 → 0.015 → 0.014 | -91% | 1 / 1 | +0.001 |
| GHZ-3 | TVD | 2 → 2 (+0%) | 12 → 10 (-17%) | 0.183 → 0.183 → 0.027 → 0.020 | -85% | 2 / 2 | +0.007 |
| GHZ-5 | TVD | 4 → 4 (+0%) | 20 → 16 (-20%) | 0.204 → 0.204 → 0.037 → 0.037 | -82% | 4 / 4 | -0.000 |
| Grover-2 | TVD | 2 → 2 (+0%) | 38 → 10 (-74%) | 0.177 → 0.175 → 0.015 → 0.015 | -91% | 2 / 2 | +0.000 |
| Grover-3 | TVD | 48 → 37 (-23%) | 307 → 133 (-57%) | 0.227 → 0.107 → 0.092 → 0.083 | -59% | 37 / 37 | +0.010 |
| QFT-3 | TVD | 15 → 9 (-40%) | 72 → 32 (-56%) | 0.200 → 0.043 → 0.037 → 0.031 | -82% | 9 / 7 | +0.006 |
| QFT-4 | TVD | 36 → 17 (-53%) | 116 → 55 (-53%) | 0.228 → 0.087 → 0.065 → 0.055 | -71% | 17 / 14 | +0.010 |
| BV-4 | TVD | 18 → 3 (-83%) | 39 → 9 (-77%) | 0.216 → 0.029 → 0.029 → 0.021 | -87% | 3 / 3 | +0.007 |
| QAOA-3 | ratio | 9 → 7 (-22%) | 56 → 32 (-43%) | 0.932 → 0.983 → 0.986 → 0.986 | +6% | 7 / 7 | +0.000 |
| QAOA-4 | ratio | 14 → 11 (-21%) | 68 → 45 (-34%) | 0.701 → 0.738 → 0.738 → 0.740 | +5% | 11 / 11 | -0.002 |

## All levels

| Circuit | Opt | Best seed | 2q gates | 2q min / median / max over seeds | Depth | Primary metric | Hellinger F | Physical qubits | Transpile s (all seeds) |
|---|---|---|---|---|---|---|---|---|---|
| Bell | 0 | 1 | 1 | 1 / 1.0 / 1 | 8 | TVD 0.172 ± 0.006 | 0.827 | 0 1 | 0.1 |
| Bell | 1 | 1 | 1 | 1 / 1.0 / 1 | 8 | TVD 0.172 ± 0.006 | 0.827 | 0 1 | 0.1 |
| Bell | 2 | 1 | 1 | 1 / 1.0 / 1 | 7 | TVD 0.015 ± 0.004 | 0.988 | 21 20 | 0.2 |
| Bell | 3 | 1 | 1 | 1 / 1.0 / 1 | 7 | TVD 0.014 ± 0.005 | 0.989 | 20 21 | 0.2 |
| GHZ-3 | 0 | 1 | 2 | 2 / 2.0 / 2 | 12 | TVD 0.183 ± 0.008 | 0.817 | 0 1 2 | 0.1 |
| GHZ-3 | 1 | 1 | 2 | 2 / 2.0 / 2 | 12 | TVD 0.183 ± 0.008 | 0.817 | 0 1 2 | 0.1 |
| GHZ-3 | 2 | 1 | 2 | 2 / 2.0 / 2 | 10 | TVD 0.027 ± 0.002 | 0.974 | 110 109 108 | 0.2 |
| GHZ-3 | 3 | 1 | 2 | 2 / 2.0 / 2 | 10 | TVD 0.020 ± 0.004 | 0.981 | 117 105 104 | 0.2 |
| GHZ-5 | 0 | 1 | 4 | 4 / 4.0 / 4 | 20 | TVD 0.204 ± 0.008 | 0.796 | 0 1 2 3 4 | 0.1 |
| GHZ-5 | 1 | 1 | 4 | 4 / 4.0 / 4 | 20 | TVD 0.204 ± 0.008 | 0.796 | 0 1 2 3 4 | 0.1 |
| GHZ-5 | 2 | 1 | 4 | 4 / 4.0 / 4 | 16 | TVD 0.037 ± 0.004 | 0.963 | 148 149 150 151 152 | 0.2 |
| GHZ-5 | 3 | 1 | 4 | 4 / 4.0 / 4 | 16 | TVD 0.037 ± 0.005 | 0.963 | 152 151 150 149 148 | 0.2 |
| Grover-2 | 0 | 1 | 2 | 2 / 2.0 / 2 | 38 | TVD 0.177 ± 0.006 | 0.823 | 0 1 | 0.1 |
| Grover-2 | 1 | 1 | 2 | 2 / 2.0 / 2 | 12 | TVD 0.175 ± 0.006 | 0.825 | 0 1 | 0.1 |
| Grover-2 | 2 | 1 | 2 | 2 / 2.0 / 2 | 10 | TVD 0.015 ± 0.001 | 0.985 | 21 20 | 0.2 |
| Grover-2 | 3 | 1 | 2 | 2 / 2.0 / 2 | 10 | TVD 0.015 ± 0.001 | 0.985 | 21 20 | 0.2 |
| Grover-3 | 0 | 14 | 48 | 48 / 51.0 / 54 | 307 | TVD 0.227 ± 0.005 | 0.874 | 0 1 2 | 0.2 |
| Grover-3 | 1 | 1 | 45 | 45 / 45.0 / 45 | 169 | TVD 0.107 ± 0.005 | 0.968 | 21 20 36 | 0.2 |
| Grover-3 | 2 | 1 | 37 | 37 / 39.0 / 39 | 133 | TVD 0.092 ± 0.004 | 0.974 | 21 20 36 | 0.2 |
| Grover-3 | 3 | 1 | 37 | 37 / 39.0 / 39 | 133 | TVD 0.083 ± 0.006 | 0.978 | 143 142 144 | 0.3 |
| QFT-3 | 0 | 2 | 15 | 15 / 15.0 / 18 | 72 | TVD 0.200 ± 0.005 | 0.800 | 2 0 1 | 0.1 |
| QFT-3 | 1 | 1 | 12 | 12 / 12.0 / 12 | 49 | TVD 0.043 ± 0.003 | 0.957 | 108 110 109 | 0.2 |
| QFT-3 | 2 | 1 | 9 | 9 / 9.0 / 9 | 32 | TVD 0.037 ± 0.003 | 0.963 | 117 104 105 | 0.2 |
| QFT-3 | 3 | 1 | 7 | 7 / 7.0 / 9 | 25 | TVD 0.031 ± 0.003 | 0.969 | 104 117 105 | 0.2 |
| QFT-4 | 0 | 2 | 36 | 36 / 36.0 / 39 | 116 | TVD 0.228 ± 0.007 | 0.772 | 3 0 2 1 | 0.1 |
| QFT-4 | 1 | 1 | 27 | 27 / 27.0 / 27 | 80 | TVD 0.087 ± 0.004 | 0.913 | 88 91 89 90 | 0.2 |
| QFT-4 | 2 | 7 | 17 | 17 / 18.0 / 19 | 55 | TVD 0.065 ± 0.004 | 0.934 | 149 152 150 151 | 0.2 |
| QFT-4 | 3 | 9 | 14 | 14 / 17.0 / 19 | 44 | TVD 0.055 ± 0.003 | 0.945 | 138 152 150 151 | 0.3 |
| BV-4 | 0 | 3 | 18 | 18 / 18.0 / 21 | 39 | TVD 0.216 ± 0.008 | 0.784 | 1 2 0 4 | 0.1 |
| BV-4 | 1 | 1 | 3 | 3 / 3.0 / 3 | 10 | TVD 0.029 ± 0.002 | 0.971 | 108 110 148 118 | 0.1 |
| BV-4 | 2 | 1 | 3 | 3 / 3.0 / 3 | 9 | TVD 0.029 ± 0.002 | 0.971 | 108 110 148 118 | 0.2 |
| BV-4 | 3 | 1 | 3 | 3 / 3.0 / 3 | 9 | TVD 0.021 ± 0.001 | 0.979 | 38 48 148 50 | 0.2 |
| QAOA-3 | 0 | 1 | 9 | 9 / 9.0 / 9 | 56 | ratio 0.932 ± 0.004 | 0.963 | 1 0 2 | 0.1 |
| QAOA-3 | 1 | 1 | 9 | 9 / 9.0 / 9 | 39 | ratio 0.983 ± 0.002 | 0.997 | 108 110 109 | 0.2 |
| QAOA-3 | 2 | 4 | 7 | 7 / 9.0 / 9 | 32 | ratio 0.986 ± 0.002 | 0.998 | 117 104 105 | 0.2 |
| QAOA-3 | 3 | 4 | 7 | 7 / 9.0 / 9 | 32 | ratio 0.986 ± 0.002 | 0.998 | 117 104 105 | 0.2 |
| QAOA-4 | 0 | 1 | 14 | 14 / 14.0 / 14 | 68 | ratio 0.701 ± 0.004 | 0.958 | 1 0 3 2 | 0.1 |
| QAOA-4 | 1 | 3 | 11 | 11 / 14.0 / 14 | 56 | ratio 0.738 ± 0.004 | 0.997 | 108 118 110 109 | 0.2 |
| QAOA-4 | 2 | 2 | 11 | 11 / 11.0 / 12 | 45 | ratio 0.738 ± 0.004 | 0.997 | 108 118 110 109 | 0.2 |
| QAOA-4 | 3 | 2 | 11 | 11 / 11.0 / 12 | 45 | ratio 0.740 ± 0.004 | 0.997 | 152 150 138 151 | 0.3 |

## Column meanings

- **Logical CX**: CNOTs before mapping to hardware (decomposed to CX + U).
- **2q gates**: two-qubit gates after transpiling (ECR on Eagle, CZ on Heron), including routing SWAPs.
- **TVD**: total variation distance from the exact distribution. 0 is perfect, 1 is completely wrong.
- **Hellinger F**: Hellinger fidelity with the exact distribution. 1 is perfect.
- **Approx. ratio**: expected cut of the measured distribution divided by the maximum cut.
- **Shot-noise TVD**: mean TVD from finite shots alone with zero hardware noise.
